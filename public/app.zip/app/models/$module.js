(function(angular){

    angular.module('app.models', ['app.services']);

})(angular);
