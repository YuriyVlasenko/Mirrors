/**
 * Created by PIPON on 28.02.2015.
 */

(function(angular){

    angular.module('app.services', []);

})(angular);
