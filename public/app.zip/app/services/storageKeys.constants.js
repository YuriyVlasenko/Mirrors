/**
 * Created by Serg on 17.05.2015.
 */


(function (angular) {
    angular.module('app.services').constant('storageKeys', {
        BASKET: 'basket',
        BASKET_ORDER:'basket_order',
        BASKET_COMMENT: 'basket_comment',
        BASKET_DETAILS: 'basket_details',
        USER_DATA: 'userData'
    });
})(angular);

